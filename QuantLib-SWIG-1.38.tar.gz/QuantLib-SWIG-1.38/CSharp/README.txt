
Visual Studio .NET projects are provided; note that before launching
the IDE, you'll have to define an environment variable QL_DIR whose
value must equal the path to your QuantLib installation, e.g.,
"C:\Lib\QuantLib".

The interfaces should also work with Mono on Linux; run 'make' in this
directory.



The QuantLib test suite is implemented on top of the Boost unit-test
framework, available from http://www.boost.org. Version 1.30.2 or later
of Boost is required.

